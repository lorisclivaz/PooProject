package MainFrame;
/*
 * Author : Vivian Bridy & Loris Clivaz
 * Date creation : 14 mai 2018
 */


/**
 * @author Loris_Clivaz
 *
 * {@link} https://github.com/lorisclivaz/PooProject.git
 */
public class MainTest 
{

	public static void main(String[] args) 
	{

		Frame frame = new Frame();
		
		
		frame.setVisible(true);
		
	}

}
